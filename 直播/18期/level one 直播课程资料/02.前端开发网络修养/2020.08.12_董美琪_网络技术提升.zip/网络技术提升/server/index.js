// http 模块
var http = require('http');
// url模块  用来解析地址
var url = require('url');
// var fs = require('fs'); // 
// 创建一个服务器  监听3000端口  服务器源地址为 http://localhost:3000/
http.createServer(function (request, response) {
    // console.log('服务已起动');
    // console.log(url.parse(request.url));
    console.log(request);
    // 获取路径
    var pathName = url.parse(request.url).pathname;
    // 获取请求数据
    var params = url.parse(request.url, true).query;
    // 判断路径  /data  主要就是用来做数据分页的 返回给客户端 客户端想要的页码的数据
    if (pathName == '/data') {
        console.log('我接受到请求了')
        var page = params.page || 1;
        var pageSize = params.size || 10;
        var dataPadding = params.callback || "JSONP";
        // 拿取要返回的响应数据
        var data = require('./data.json');
        // 对返回的数据进行处理
        data = data.filter(function (item, index) {
            return index >= (page - 1) * pageSize && index < page * pageSize;
        });
        console.log('我接受到请求了')
        // 添加响应头
        response.writeHead(200, {
            "Access-Control-Allow-Origin": "*",
            "Access-Control-Allow-Methods": "PUT,DELETE",
            "Access-control-Allow-Headers": "Content-Type",
        });
        // 添加响应体 jsonp 的返回信息
        // response.write(dataPadding + '(' + JSON.stringify(data) + ')');
        // 正常的返回信息
        response.write(JSON.stringify(data));
        // 断开连接
        response.end();
    }
}).listen(3000);