(function ($) {
    /**
     * 存储当前轮播图的数据信息
     * @param {Object} options 
     *      1）轮播的区域：  内容应该为一个数组 数组中的每一项为每次轮播的内容（DOM元素）
                list: [dom, dom]
            2) 尺寸： width, height
            3) 轮播的方式： type:  'animation'(从左到右的轮播) 'fade' (淡入淡出的轮播)
            4）是否自动轮播： autoChange: true （自动轮播） false （不自动轮播）
            5）自动轮播时间： autoTime
            6) 是否展示小圆点: showSpotBtn : true （展示） false（不展示
            7）是否展示左右按钮：  showChangeBtn: 'always', 'hover', 'hidden'
            8) 小圆点的位置： spotPosition： 'left'， 'right', 'center'
     */
    function Swiper(options, wrap) {
        this.list = options.list || [];
        this.width = options.width || $(wrap).width();
        this.height = options.height || $(wrap).height();
        this.type = options.type || 'fade';
        this.autoChange = typeof options.autoChange === 'undefined' ? true : options.autoChange;
        this.autoTime = options.autoTime || 5000;
        this.showSpotBtn = typeof options.showSpotBtn === 'undefined' ? true : options.showSpotBtn;
        this.showChangeBtn = options.showChangeBtn || 'always';
        this.spotPosition = options.spotPosition || 'left';
        this.num = this.list.length;
        this.wrap = wrap;
    }
    // 初始化结构与行为
    Swiper.prototype.init = function () {
        this.createDom();
        this.initStyle();
        this.bindEvent();
    }
    // 创建html结构
    Swiper.prototype.createDom = function () {
        var swiperWrapper = $('<div class="my-swiper"></div>');
        var domList = $('<ul class="my-swiper-list"></ul>');
        var spotsBtn = $('<div class="my-swiper-spots"></div>');
        var len = this.list.length;
        for (var i = 0; i < len; i++) {
            var oLi = $('<li class="my-swiper-item"></li>');
            oLi.append(this.list[i]).appendTo(domList);
            spotsBtn.append($('<span></span>'));
        }
        if (this.type === 'animation') {
            domList.append($('<li class="my-swiper-item"></li>').append($(this.list[0]).clone(true)));
        }
        var leftBtn = $('<div class="my-swiper-btn my-swiper-lbtn">&lt;</div>')
        var rightBtn = $('<div class="my-swiper-btn my-swiper-rbtn">&gt;</div>')
        swiperWrapper.append(domList)
                    .append(leftBtn)
                    .append(rightBtn)
                    .append(spotsBtn)
                    .appendTo(this.wrap)
                    .addClass("my-swiper-" + this.type);
    }
    // 动态设置样式
    Swiper.prototype.initStyle = function () {
        // $(选择器, 选择器的作用域（即哪个元素下面去找）)
        $('.my-swiper', this.wrap).css({
            width: this.width,
            height: this.height
        }).find('.my-swiper-list').css({
            width: this.type === 'animation' ? this.width * ( this.num + 1 ): this.width
        }).find('.my-swiper-item').css({
            width: this.width
        }).end().end().find('.my-swiper-spots').css({
            textAlign: this.spotPosition,
            display: this.showSpotBtn ? 'block' : 'none'
        });

        if (this.showChangeBtn === 'always') {
            $('.my-swiper > .my-swiper-btn', this.wrap).css({
                display: 'block'
            })
        } else if (this.showChangeBtn === 'hidden') {
            $('.my-swiper > .my-swiper-btn', this.wrap).css({
                display: 'none'
            })
        } else if (this.showChangeBtn === 'hover') {
            $('.my-swiper', this.wrap).hover(function () {
                $('.my-swiper > .my-swiper-btn', this.wrap).css({
                    display: 'block'
                });
            }, function () {
                $('.my-swiper > .my-swiper-btn', this.wrap).css({
                    display: 'none'
                });
            });
        }
        // this.wrap.find('.my-swiper')
    }
    // 实现动效行为
    Swiper.prototype.bindEvent = function () {

    }


    $.fn.extend({
        swiper: function(options) {
            var obj = new Swiper(options, this);
            obj.init();
        }
    })
} ($ || jQuery))

