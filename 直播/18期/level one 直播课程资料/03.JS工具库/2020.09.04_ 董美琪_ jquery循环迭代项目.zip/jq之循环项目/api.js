// 所有接口的集合
var api = {
  /**
   * 用来做获取表格数据的
   */
  getStudentData: function (data) {
    /** 网络请求 */
    var result = [];
    var size = data.size || 10;
    for (var i = 0; i < size; i++) {
      result.push(
        Mock.mock({
          sNo: Mock.Random.integer(999, 999999999),
          name: "@name",
          sex: Mock.Random.integer(0, 1),
          birth: '@date("yyyy")',
          phone: /^1[3-9]\d{9}$/,
          email: "@email",
          address: Mock.Random.county(true),
        })
      );
    }
    return {
        status: 'success',
        msg: '成功',
        data: {
            count: Mock.Random.integer(),
            findByPage: result
        }
    };
  },
  updateStudent: function (data) {
      console.log(data);
      return {
        status: 'success',
        msg: '成功',
        data: {}
    };
  },
  removeStudent: function (sNo) {
      console.log(sNo);
      return {
        status: 'success',
        msg: '成功',
        data: {}
      }
  }
};

