// 所有接口的集合
var api = {
  /**
   * 用来做获取表格数据的
   */
  getStudentData: function (data) {
    /** 网络请求 */
    // var result = [];
    // var size = data.size || 10;
    // for (var i = 0; i < size; i++) {
    //   result.push(
    //     Mock.mock({
    //       sNo: Mock.Random.integer(999, 999999999),
    //       name: "@name",
    //       sex: Mock.Random.integer(0, 1),
    //       birth: '@date("yyyy")',
    //       phone: /^1[3-9]\d{9}$/,
    //       email: "@email",
    //       address: Mock.Random.county(true),
    //     })
    //   );
    // }
    // var df = $.Deferred();
    // // resolve reject
    // setTimeout(function () {
    //   df.resolve({
    //     status: "success",
    //     msg: "成功",
    //     data: {
    //       count: Mock.Random.integer(),
    //       findByPage: result,
    //     },
    //   });
    // }, 500);
    return $.ajax({
      type: 'get',
      url: 'http://open.duyiedu.com/api/student/findByPage',
      dataType: 'json',
      data: $.extend(data, {
        appkey: 'DuYimeiqi_1564986205860'
      })
    });
  },
  updateStudent: function (data) {
    // console.log(data);
    var df = $.Deferred();
    setTimeout(function () {
      df.resolve({
        status: "success",
        msg: "成功",
        data: {},
      });
    }, 30);
    return df;
    // return $.ajax({
    //   type: 'get',
    //   url: 'http://open.duyiedu.com/api/student/updateStudent',
    //   dataType: 'JSON',
    //   data: $.extend(data, {
    //     appkey: 'DuYimeiqi_1564986205860'
    //   })
    // });
  },
  removeStudent: function (sNo) {
    // console.log(sNo);
    // var df = $.Deferred();
    // setTimeout(function () {
    //   df.resolve({
    //     status: "success",
    //     msg: "成功",
    //     data: {},
    //   });
    // }, 30);
    return $.ajax({
      type: 'get',
      url: 'http://open.duyiedu.com/api/student/delBySno',
      dataType: 'json',
      data: {
        sNo: sNo,
        appkey: 'DuYimeiqi_1564986205860'
      }
    });
  },
};
