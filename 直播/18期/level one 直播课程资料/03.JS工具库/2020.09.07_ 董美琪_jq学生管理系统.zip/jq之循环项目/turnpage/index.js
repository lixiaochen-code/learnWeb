(function () {
  // 存储翻页信息的构造函数
  function Page(options, wrap) {
    // 总页数
    this.total = options.total || 1;
    // 当前页码
    this.current = options.current || 1;
    // 每一页的条数
    this.size = options.size || 10;
    // 当切换页码的时候 执行的回调函数
    this.change = options.change || function (){};
    this.wrap = wrap;
  }
  Page.prototype.init = function () {
    // 创建翻页的结构
    this.createDom();
    // 实现切换功能
    this.changePage();
  };
  Page.prototype.createDom = function () {
    var pageWrapper = $('<div class="my-page"></div>');
    // 上一页
    if (this.current > 1) {
      $('<div class="my-page-prev-btn">上一页</div>').appendTo(pageWrapper);
    }
    $('<div class="my-page-num">1</div>')
      .appendTo(pageWrapper)
      .addClass(this.current === 1 ? "my-page-current" : "");
    // 前面的省略号
    if (this.current - 2 - 1 > 1) {
      $("<span>...</span>").appendTo(pageWrapper);
    }
    // 中间五页
    for (var i = this.current - 2; i <= this.current + 2; i++) {
      if (i > 1 && i < this.total) {
        $('<div class="my-page-num"></div>')
          .text(i)
          .appendTo(pageWrapper)
          .addClass(this.current === i ? "my-page-current" : "");
      }
    }

    // 后面的省略号
    if (this.current + 2 + 1 < this.total) {
      $("<span>...</span>").appendTo(pageWrapper);
    }

    // 插入最后一页
    this.total > 1 &&
      $('<div class="my-page-num"></div>')
        .text(this.total)
        .appendTo(pageWrapper)
        .addClass(this.current === this.total ? "my-page-current" : "");
    // 下一页
    if (this.current < this.total) {
      $('<div class="my-page-next-btn">下一页</div>').appendTo(pageWrapper);
    }
    // 清空之前的结构  插入现在的翻页
    $(this.wrap).empty().append(pageWrapper);
  };

  Page.prototype.changePage = function () {
      var self = this;
    //   $('.my-page', this.wrap);
      $(this.wrap).find('.my-page')
                  .on('click', '.my-page-prev-btn', function () {
                     self.current --;
                     self.init();
                    // self.createDom();
                    self.change(self.current);
                  }).on('click', '.my-page-next-btn', function () {
                    self.current ++;
                    self.init();
                    // self.createDom();
                    self.change(self.current);
                 }).on('click', '.my-page-num', function () {
                    self.current  = parseInt($(this).text());
                    self.init();
                    // self.createDom();
                    self.change(self.current);
                 })
  }

  $.fn.extend({
    page: function (options) {
      var obj = new Page(options, this);
      obj.init();
    },
  });
})();
