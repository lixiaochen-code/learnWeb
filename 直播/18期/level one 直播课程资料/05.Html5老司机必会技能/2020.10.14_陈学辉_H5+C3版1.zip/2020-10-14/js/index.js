function init(){
    bindEvent();
    //

    location.hash='student-list';
}
init();

function bindEvent(){
    var list=$('header .drop-list');
    $('header .btn').click(function(){
        list.slideToggle();
    });

    $(window).resize(function(){
        if($(window).innerWidth()>=768){
            list.css('display','none');
        }
    });

    $(window).on('hashchange',function(){
        var hash=location.hash; //#student-list

        $('.show-list').removeClass('show-list');
        $(hash).addClass('show-list');

        $('.list-item.active').removeClass('active');
        $('.'+hash.slice(1)).addClass('active');
    });

    $('.list-item').click(function(){
        $('.drop-list').slideUp();
        var id=$(this).attr('data-id');
        location.hash=id;
    });
}