// 多页配置
module.exports = {
  "hero-search": {
    js: "./src/pages/hero-search", // 页面入口js
    html: "./src/pages/hero-search/index.html", // 页面使用的html模板
    out: "hero-search.html", // 输出目录中的页面文件名
  },
};
