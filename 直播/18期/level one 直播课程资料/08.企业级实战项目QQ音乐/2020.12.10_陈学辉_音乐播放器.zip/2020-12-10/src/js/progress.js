(function (root) {
    //进度条，构造函数
    function Progress() {
        this.durTime = 0; //总时间
        this.frameId = null;  //定时器
        this.startTime = 0;   //进度条起始的时间
        this.lastPercent = 0; //上次走的百分比

        this.init();
    }
    Progress.prototype = {
        init: function () {
            //console.log(123);
            this.getDom();

            this.renderAllTime(266);
        },
        getDom: function () {
            this.curTime = document.querySelector('.curTime');
            this.circle = document.querySelector('.circle');
            this.frontBg = document.querySelector('.frontBg');
            this.totalTime = document.querySelector('.totalTime');
        },
        renderAllTime: function (time) {
            this.durTime = time;
            time = this.formatTime(time);

            this.totalTime.innerHTML = time;
        },
        formatTime: function (time) {
            time = Math.round(time);
            //266
            var m = Math.floor(time / 60);
            var s = time % 60;

            m = m < 10 ? '0' + m : m;
            s = s < 10 ? '0' + s : s;

            return m + ':' + s;
        },
        move: function (per) {    //移动进度条
            cancelAnimationFrame(this.frameId); //在开启新的定时器的时候需要先清除上次的定时器
            var This = this;
            this.startTime = new Date().getTime();


            //per决定了上一次走的百分比是否要清空，如果没有传参数表示不需要清空，如果传了参数表示要清空
            this.lastPercent = per === undefined ? this.lastPercent : per;

            function frame() {
                var curTime = new Date().getTime();
                var per = This.lastPercent + (curTime - This.startTime) / (This.durTime * 1000);

                if (per <= 1) {
                    //这个条件成立说明歌曲还没有播放完
                    This.update(per);
                } else {
                    //走到这里说明歌曲已经播放完了，需要关闭定时
                    cancelAnimationFrame(This.frameId);
                }

                This.frameId = requestAnimationFrame(frame);
            }
            frame();
        },
        update: function (per) {  //更新进度条
            // console.log('update');

            //更新左侧时间
            var time = this.formatTime(per * this.durTime);
            this.curTime.innerHTML = time;

            //更新进度条的位置
            this.frontBg.style.width = per * 100 + '%';

            //更新圆点的位置
            var l = per * this.circle.parentNode.offsetWidth;
            this.circle.style.transform = 'translateX(' + l + 'px)';
        },
        stop: function () {    //停止进度条
            cancelAnimationFrame(this.frameId);

            var stopTime = new Date().getTime();
            this.lastPercent += (stopTime - this.startTime) / (this.durTime * 1000);
        }
    }

    //实例化
    function instancesProgress() {
        return new Progress();
    }



    //拖拽
    function Drag(obj) {
        this.obj = obj;   //拖拽的对象
        this.startPointX = 0; //按下的时候x轴的坐标
        this.startLeft = 0;   //按下的时候已经走的距离
        this.percent = 0; //走的百分比
    }
    Drag.prototype = {
        init: function () {
            var This = this;
            this.obj.style.transform = 'translateX(0px)';

            //拖拽开始，手指按下
            this.obj.addEventListener('touchstart', function (ev) {
                This.startPointX = ev.changedTouches[0].pageX;    //按下的时候记录第一根手指的坐标点
                This.startLeft = parseFloat(this.style.transform.split('(')[1]);

                This.start && This.start(); //给用户留的一个方法，如果用户定义了，这个方法在这里会被调用 
            });

            this.obj.addEventListener('touchmove', function (ev) {
                This.disPointX=ev.changedTouches[0].pageX-This.startPointX; //手指走的距离
                var l= This.startLeft+This.disPointX;   //当前要走到的位置

                if(l<0){
                    l=0;
                }else if(l>this.offsetParent.offsetWidth){
                    l=this.offsetParent.offsetWidth;
                }

                this.style.transform='translateX('+l+'px)';


                //拖拽的百分比
                This.percent=l/this.offsetParent.offsetWidth
                This.move && This.move(This.percent); //给用户留的一个方法，如果用户定义了，这个方法在这里会被调用 

                ev.preventDefault();
            });

            this.obj.addEventListener('touchend', function (ev) {
                This.end && This.end(This.percent); //给用户留的一个方法，如果用户定义了，这个方法在这里会被调用 
            });
        }
    };

    //实例化
    function instancesDrag(obj) {
        return new Drag(obj);
    }

    root.progress = {
        pro: instancesProgress,
        drag: instancesDrag,
    }

})(window.player || (window.player = {}));