// 只有所有的任务全部成功，新的Promise才能成功，有任何一个任务失败，新的Promise都会失败
// var pro1 = Promise.all([
//   Promise.resolve(1),
//   Promise.resolve(2),
//   Promise.reject(3),
// ]);

// pro1
//   .then((result) => {
//     console.log(result);
//   })
//   .catch((err) => {
//     console.log("error", err);
//   });

// 只要有一个完成了，新的Promise成功，只要有一个失败了，新的Promise就会失败
// var pro1 = Promise.race([
//   Promise.resolve(1),
//   Promise.resolve(2),
//   Promise.reject(3),
// ]);

// pro1
//   .then((result) => {
//     console.log(result);
//   })
//   .catch((err) => {
//     console.log("error", err);
//   });

// 只要全部的Promise已决，新的Promise成功，否则，新的Promise是pending
var pro1 = Promise.allSettled([
  Promise.resolve(1),
  Promise.resolve(2),
  Promise.reject(3),
]);

pro1
  .then((result) => {
    console.log(result);
  })
  .catch((err) => {
    console.log("error", err);
  });
