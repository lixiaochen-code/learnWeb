var obj = {
  a: 1,
  b: 2,
};

// // 语法
// delete obj.a;

// // API
// Reflect.deleteProperty(obj, "a");

// console.log(obj.a);
// console.log(Reflect.get(obj, "a"));
