import axios from 'axios';
import URLs from './URLs';

const appkey = 'Q_A_Q_1590927055348';

const ajax = axios.create({
  baseURL: URLs.baseURL,
  params: {
    appkey,
  },
});

ajax.interceptors.response.use((data) => {
  const newData = data.data;
  if (newData.status === 'success') {
    return newData;
  }
  return Promise.reject(newData.msg);
});

const login = (data) => ajax.post(URLs.login, `appkey=${appkey}&${data}`);
const logon = (data) => ajax.post(URLs.logon, `appkey=${appkey}&${data}`);
const getStu = (page, size) => ajax.get(URLs.getStu, {
  params: {
    page,
    size,
  },
});
const updateStu = (config) => ajax.get(URLs.updateStu, {
  params: {
    ...config,
  },
});

export default {
  login,
  logon,
  getStu,
  updateStu,
};
