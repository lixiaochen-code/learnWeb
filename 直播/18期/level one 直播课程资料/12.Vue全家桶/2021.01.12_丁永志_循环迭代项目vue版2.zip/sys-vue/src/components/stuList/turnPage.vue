<template>
  <div class="turn-page">
    <div id="prev-btn">上一页</div>
    <div id="next-btn">下一页</div>
  </div>
</template>

<script>
export default {};
</script>

<style>
</style>
