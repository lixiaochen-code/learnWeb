import Vue from 'vue';
import Vuex from 'vuex';
import api from '../api';

Vue.use(Vuex);

export default new Vuex.Store({
  state: {
    list: [],
    show: false,
    size: 10,
    totalPage: 1,
    nowPage: 1,
    activeStu: null,
  },
  mutations: {
    setList(state, list) {
      state.list = list;
    },
    setShowModal(state, bool) {
      state.show = bool;
    },
    // 未完成
    setTotalPage(state, count) {
      state.totalPage = count;
    },
    setActiveStu(state, stu) {
      state.activeStu = stu;
    },
  },
  actions: {
    async getStu({ state, commit }, page) {
      const { data: { cont: count, findByPage: list } } = await api.getStu(page, state.size);
      commit('setList', list);
      commit('setTotalPage', count);
    },
  },
  modules: {
  },
});
