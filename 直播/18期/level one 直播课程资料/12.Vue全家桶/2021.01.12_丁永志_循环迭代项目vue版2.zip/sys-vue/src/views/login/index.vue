<template>
  <form action="#" id="login">
    <h2>
      登录
      <router-link to="/logon">注册</router-link>
    </h2>
    <div>
      <label for="account"> 账号: </label>
      <input type="text" id="account" v-model="account" />
    </div>
    <div>
      <label for="password">密码:</label>
      <input type="password" id="password" v-model="password" />
    </div>
    <div>
      <label for=""></label>
      <input class="btn" type="button" value="提交" @click="login" />
      <input class="btn" type="button" value="重置" @click="reset"/>
    </div>
  </form>
</template>

<script>
export default {
  data() {
    return {
      account: '',
      password: '',
    };
  },
  methods: {
    reset() {
      this.account = '';
      this.password = '';
    },
    async login() {
      if (this.account && this.password) {
        try {
          const result = await this.$api.login(`account=${this.account}&password=${this.password}`);
          console.log(result);
          this.Cookie.setCookie('username', this.account);
          this.$router.push('/main');
        } catch (error) {
          console.log(error);
        }
      }
    },
  },
  created() {
    this.Cookie.setCookie('username', '', -1);
  },
};
</script>

<style scoped src="./login.css">
/* @import url(./login.css); */
</style>
