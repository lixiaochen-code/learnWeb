<template>
  <form action="#" id="register">
    <h2>
      注册
      <router-link to="/login">登录</router-link>
    </h2>
    <div>
      <label for="username"> 用户名: </label>
      <input type="text" id="username" name="username" v-model="username" />
    </div>
    <div>
      <label for="account"> 账号: </label>
      <input type="text" id="account" name="account" v-model="account" />
    </div>
    <div>
      <label for="password">密码:</label>
      <input type="password" id="password" name="password" v-model="password" />
    </div>
    <div>
      <label for="rePassword">确认密码:</label>
      <input type="password" id="rePassword" name="rePassword" v-model="rePassword" />
    </div>
    <div>
      <label for=""></label>
      <input class="btn" type="button" value="注册" @click="logon" />
      <input class="btn" type="button" value="重置" @click="reset" />
    </div>
  </form>
</template>

<script>
export default {
  data() {
    return {
      username: '',
      account: '',
      password: '',
      rePassword: '',
    };
  },
  methods: {
    async logon() {
      if (this.account && this.username && this.password && this.rePassword) {
        if (this.password === this.rePassword) {
          try {
            const result = await this.$api.logon(`account=${this.account}&username=${this.username}&password=${this.password}&rePassword=${this.rePassword}`);
            console.log(result);
            this.$router.push('/login');
          } catch (error) {
            console.log(error);
          }
        }
      }
    },
    reset() {
      this.username = '';
      this.account = '';
      this.password = '';
      this.rePassword = '';
    },
  },
};
</script>
<!-- style src vue-loader src 引入的文件中追加 hash， 打上标记-->
<!-- @import css-loader style-loader 引入并插入到 style，并不会产生标记-->
<style scoped src="../login/login.css">
/* @import url(../login/login.css); */
</style>
