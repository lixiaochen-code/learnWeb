<template>
  <div>
    <div class="header">
      <div class="logo">
        <img src="@/assets/logo.png" alt="" />
        <span>渡一教育</span>
      </div>
      <ul class="user">
        <li class="username" id="username">张三123</li>
        <router-link tag="li" class="logout" to="/login">
          退出
        </router-link>
      </ul>
    </div>
    <div class="left-menu">
      <dl class="menu">
        <dt>学生管理</dt>
        <router-link tag="dd" :to="{ name: 'stuList'}">学生列表</router-link>
        <router-link tag="dd" :to="{ name: 'addStu'}">新增学生</router-link>
      </dl>
    </div>
    <div class="right-content">
      <router-view></router-view>
    </div>
  </div>
</template>

<script>
export default {};
</script>

<style>
  @import url(./index.css);
</style>
