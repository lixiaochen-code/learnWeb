<template>
  <div id="student-list">
    <sys-table></sys-table>
    <transition>
      <show-modal v-if="show"></show-modal>
    </transition>
    <turn-page></turn-page>
  </div>
</template>

<script>
import sysTable from '@/components/stuList/sysTable.vue';
import turnPage from '@/components/stuList/turnPage.vue';
import showModal from '@/components/stuList/showModal.vue';
import { mapState } from 'vuex';

export default {
  computed: {
    ...mapState(['show']),
  },
  components: {
    sysTable,
    turnPage,
    showModal,
  },
};
</script>

<style>
  /* .v-enter, .v-enter-to,
  .v-leave, .v-leave-to,
  .v-leave-active, .v-enter-active */
  .v-enter, .v-leave-to {
    top: -100%;
    opacity: 0;
  }
  .v-enter-to, .v-leave {
    top: 0;
    opacity: 1;
  }
  .v-enter-active, .v-leave-active {
    transition: all .5s;
  }
</style>
