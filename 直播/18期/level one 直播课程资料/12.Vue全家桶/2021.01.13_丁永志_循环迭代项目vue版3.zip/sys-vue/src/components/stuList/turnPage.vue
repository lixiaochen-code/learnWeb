<template>
  <div class="turn-page">
    <div id="prev-btn" @click="turnPage('prev')" :class="prevClass">&lt;</div>
    <template v-if="totalPage <= 7">
      <div
      v-for="i in totalPage"
      :key="i"
      :class="{ active: i === nowPage }"
      @click="turnPage(i)"
      >{{ i }}</div>
    </template>
    <template v-else>
      <!-- 123456, ... 100 -->
      <!-- 1 ..., 95,96,97,98,99,100 -->
      <!-- 1..., np-2 np-1 np np+1 np+2 ,...100 -->

      <!-- 123456 np < 5-->
      <template v-if="nowPage < 5">
        <div
        v-for="i in 6"
        :key="i"
        @click="turnPage(i)"
        :class="{active: i === nowPage}"
        >{{i}}</div>
      </template>
      <!-- 1... np >=5 -->
      <template v-if="nowPage >= 5">
        <div @click="turnPage(1)">1</div>
        <div @click="turnPage(nowPage - 5 > 0 ? nowPage - 5 : 1)">...</div>
      </template>
      <!-- np-3 + 1 np-3+2 np -3 + 3 np+1 np+2 np>=5 && np <= tp -4 -->
      <template v-if="nowPage >=5 && nowPage <= totalPage - 4">
        <div
        v-for="i in 5"
        :key="i"
        @click="turnPage(nowPage - 3 + i)"
        :class="{ active : i == 3 }"
        >{{ nowPage - 3 + i }}</div>
      </template>
      <!-- ... tp, np <= tp -4 -->
      <template v-if="nowPage <= totalPage - 4">
        <div @click="turnPage(nowPage + 5 > totalPage ? totalPage : nowPage + 5)">...</div>
        <div @click="turnPage(totalPage)">{{ totalPage }}</div>
      </template>
      <!-- tp-6 + 1, tp-6 + 2, tp-3, tp-2, tp-1, tp np > tp -4 -->
      <template v-if="nowPage > totalPage - 4">
        <div
        v-for="i in 6"
        :key="i"
        @click="turnPage(totalPage - 6 + i)"
        :class="{active: totalPage - 6 + i === nowPage}"
        >{{totalPage - 6 + i}}</div>
      </template>

    </template>
    <template></template>
    <div id="next-btn" @click="turnPage('next')" :class="nextClass">&gt;</div>
  </div>
</template>

<script>
export default {
  // data() {
  //   return {
  //     nowPage: 1,
  //     totalPage: 100,
  //   };
  // },
  props: {
    totalPage: {
      type: Number,
      default: 99,
    },
    nowPage: {
      type: Number,
      default: 1,
    },
  },
  methods: {
    turnPage(i) {
      let np = null;
      if (i === 'prev') {
        if (this.nowPage > 1) {
          // this.nowPage -= 1;
          np = this.nowPage - 1;
        }
      } else if (i === 'next') {
        if (this.nowPage < this.totalPage) {
          // this.nowPage += 1;
          np = this.nowPage + 1;
        }
      } else {
        // this.nowPage = i;
        np = i;
      }
      if (np == null) {
        return;
      }
      this.$emit('current-page', np);
    },
  },
  computed: {
    prevClass() {
      if (this.nowPage === 1) {
        return 'not-allow';
      }
      return '';
    },
    nextClass() {
      if (this.nowPage === this.totalPage) {
        return 'not-allow';
      }
      return '';
    },
  },
};
</script>

<style scoped>
 .turn-page {
   display: flex;
   position: absolute;
   left:50%;
   transform: translateX(-50%);
   user-select: none;
 }
 .turn-page > div {
    padding: 0 4px;
    font-size: 13px;
    min-width: 35.5px;
    height: 28px;
    line-height: 28px;
    cursor: pointer;
    box-sizing: border-box;
    text-align: center;
    font-weight: 600;
 }
 .turn-page > div:hover {
   color: #409eff;
 }
 .turn-page > .active {
   color: #409eff;
   cursor: default;
 }
 .not-allow {
   cursor: not-allowed!important;
 }
 .not-allow:hover {
   color: #000!important;
 }
</style>
