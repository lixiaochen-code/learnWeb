import Vue from 'vue';
import App from './App.vue';
import router from './router';
import store from './store';
import api from './api';
import Cookie from './util/cookie';
import Toast from './util/Toast';

Vue.config.productionTip = false;
Vue.prototype.$api = api;
Vue.prototype.Cookie = Cookie;
Vue.prototype.$toast = Toast;

new Vue({
  router,
  store,
  render: (h) => h(App),
}).$mount('#app');
