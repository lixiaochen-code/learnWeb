import Vue from 'vue';
import Vuex from 'vuex';
import api from '../api';

Vue.use(Vuex);

export default new Vuex.Store({
  state: {
    list: [],
    show: false,
    size: 2,
    totalPage: 1,
    nowPage: 1,
    activeStu: null,
    count: 0,
  },
  mutations: {
    setList(state, list) {
      state.list = list;
    },
    setShowModal(state, bool) {
      state.show = bool;
    },
    // 未完成
    setTotalPage(state, count) {
      state.count = count;
      state.totalPage = Math.ceil(count / state.size);
    },
    setActiveStu(state, stu) {
      state.activeStu = stu;
    },
    setNowPage(state, p) {
      state.nowPage = p;
    },
  },
  actions: {
    async getStu({ state, commit }, page) {
      const { data: { cont: count, findByPage: list } } = await api.getStu(page, state.size);
      commit('setList', list);
      commit('setTotalPage', count);
      commit('setNowPage', page);
    },
    async delStu({ state, dispatch }, sNo) {
      await api.delStu(sNo);
      let page = Math.ceil((state.count - 1) / state.size);
      if (state.nowPage > page) {
        page = state.nowPage - 1;
      } else {
        page = state.nowPage;
      }
      dispatch('getStu', page);
    },
  },
  modules: {
  },
});
