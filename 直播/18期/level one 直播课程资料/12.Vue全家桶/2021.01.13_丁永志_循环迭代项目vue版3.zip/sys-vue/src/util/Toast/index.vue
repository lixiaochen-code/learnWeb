<template>
 <div
    class="toast-wrapper"
    :class="[type, animate]"
    v-if="exist"
    >
    <div class="toast-content">{{ msg }}</div>
  </div>
</template>

<script>
export default {
  data() {
    return {
      show: true,
      exist: true,
    };
  },
  computed: {
    animate() {
      return this.show ? 'fade-in' : 'fade-out';
    },
  },
};
</script>

<style>
    .toast-wrapper {
      width: 260px;
      height: 60px;
      line-height: 60px;
      text-align: center;
      position: fixed;
      /* position: relative; */
      top: 0;
      margin-top: 30px;
      border-radius: 10px;
      left: calc(50% - 130px);
      z-index: 800;
    }
    .success {
      background-color: #67c23a;
    }
    .fail {
      background-color: #f56c6c;
    }
    .toast-content {
      color: #fff;
      font-weight: 600;
    }
    @keyframes fadeIn {
      0% {
        top: -100px;
        opacity: 0;
      }
      100% {
        top: 0px;
        opacity: 1;
      }
    }
    @keyframes fadeOut {
      100% {
        top: -100px;
        opacity: 0;
      }
      0% {
        top: 0px;
        opacity: 1;
      }
    }
    .fade-in {
      animation: fadeIn .5s forwards;
    }
    .fade-out {
      animation: fadeOut .5s forwards;
    }
  </style>
