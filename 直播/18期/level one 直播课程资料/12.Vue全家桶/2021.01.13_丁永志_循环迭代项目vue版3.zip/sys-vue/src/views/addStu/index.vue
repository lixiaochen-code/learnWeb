<template>
  <div id="student-add">
    <form action="#" id="add-student-form">
      <div>
        <label for="name">姓名</label
        ><input type="text" id="name" name="name" v-model="user.name" />
      </div>
      <div>
        <label for="">性别</label>
        <input type="radio" name="sex" id="male" value="0" v-model="user.sex" />
        <label for="male" class="sex">男</label>
        <input type="radio" name="sex" id="female" value="1" v-model="user.sex" />
        <label for="female" class="sex">女</label>
      </div>
      <div>
        <label for="email">邮箱</label
        ><input type="email" id="email" name="email" v-model="user.email" />
      </div>
      <div>
        <label for="number">学号</label
        ><input type="text" id="number" name="sNo" v-model="user.sNo"/>
      </div>
      <div>
        <label for="birthYear">出生年</label
        ><input type="text" id="birthYear" name="birth" v-model="user.birth" />
      </div>
      <div>
        <label for="phone">手机号</label
        ><input type="text" id="phone" name="phone" v-model="user.phone" />
      </div>
      <div>
        <label for="address">住址</label
        ><input type="text" id="address" name="address" v-model="user.address" />
      </div>
      <div>
        <label for=""></label>
        <button id="add-submit" class="btn" @click.prevent="commit">提交</button>
        <input type="reset" class="btn" @click.prevent="reset" />
      </div>
    </form>
  </div>
</template>

<script>
export default {
  data() {
    return {
      user: {
        name: '',
        sex: 0,
        email: '',
        birth: '',
        phone: '',
        address: '',
        sNo: '',
      },
    };
  },
  methods: {
    async commit() {
      try {
        const res = await this.$api.addStu(this.user);
        console.log(res);
      } catch (error) {
        console.log(error);
      }
    },
    reset() {
      this.user = {
        name: '',
        sex: 0,
        email: '',
        birth: '',
        phone: '',
        address: '',
        sNo: '',
      };
    },
  },
};
</script>

<style>
</style>
