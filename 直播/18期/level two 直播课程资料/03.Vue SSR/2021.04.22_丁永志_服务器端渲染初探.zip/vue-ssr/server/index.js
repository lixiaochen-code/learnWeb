const express = require('express');
const serverRender = require('vue-server-renderer');
const fs = require('fs');
const Vue = require('vue');
const app = express();

// 开发问题：页面组件咋写
// 页面失活：返回内容不具有Vue特性。

const vm = new Vue({
  // el:
  template: '<div>{{val}}<input v-model="val"></div>',
  data() {
    return {
      val: '你好 SSR'
    }
  }
});
// vm(vue 实例，组件) => html字符串 vue-server-renderer
// 1. 创建一个Render，render(vm) => html
const Render = serverRender.createRenderer({
  // vue实例插入的页面模板
  template: fs.readFileSync('./index.ssr.html', 'utf8')
});


app.get('*', async (req, res) => {
  // Render.renderToString(vm, {title: 'SSR', desc: '这是一个SSR页面'} ,(err, html) => res.send(html));
  try {
    const html = await Render.renderToString(vm, {title: 'SSR', desc: '这是一个SSR页面'});
    res.send(html);
  } catch (error) {
    res.status(500).send('服务器错误');
  }
});

app.listen(12306, () => console.log('server is running at 12306'));