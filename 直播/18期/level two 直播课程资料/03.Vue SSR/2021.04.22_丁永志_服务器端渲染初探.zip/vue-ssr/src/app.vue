<template>
  <div>
    <h1>我是Vue根组件</h1>
    <router-link to="/">home</router-link>
    <router-link to="/about">about</router-link>
    <router-view></router-view>
  </div>

</template>

<script>
export default {

}
</script>

<style>

</style>