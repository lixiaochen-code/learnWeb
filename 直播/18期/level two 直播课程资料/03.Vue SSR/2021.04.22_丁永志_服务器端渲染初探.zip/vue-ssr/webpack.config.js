/**
 * webpack: webpack webpack-cli webpack-dev-server webpack-merge
 * vue: vue-loader vue-template-compiler
 * js: babel-loader @babel/core @babel/preset-env
 * css: vue-style-loader css-loader
 * other: html-webpack-plugin
 * 
 *  */ 
const HtmlWebpackPlugin = require('html-webpack-plugin');
const path = require('path');
const { VueLoaderPlugin } = require('vue-loader');
const resolve = dir => path.resolve(__dirname, dir);

module.exports = {
  entry: './src/main.js',
  output: {
    filename: 'bundle.js',
    path: resolve('./dist')
  },
  resolve: {
    extensions: ['.js', '.vue'],
  },
  module: {
    rules: [
      {
        // vue
        test: /.vue$/,
        use: 'vue-loader'
      },
      {
        // js
        test: /.js$/,
        use: {
          loader: 'babel-loader',
          options: {
            presets: ['@babel/preset-env']
          }
        },
        exclude: /node_modules/
      },
      {
        // css
        test: /.css$/,
        use: ['vue-style-loader', 'css-loader']
      }
    ]
  },
  plugins: [
    new VueLoaderPlugin(),
    new HtmlWebpackPlugin({
      filename: 'index.html',
      template: resolve('./public/index.html')
    })
  ]
}