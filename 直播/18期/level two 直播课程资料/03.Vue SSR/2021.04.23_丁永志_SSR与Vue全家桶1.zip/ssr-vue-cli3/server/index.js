const express = require('express')
const ServerRender = require('vue-server-renderer');
const fs = require('fs');
const path = require('path');
const app = express();
// const serverBundle = fs.readFileSync('../dist/server.bundle.js', 'utf8');
const serverBundle = require('../dist/vue-ssr-server-bundle.json');
const clientManifest = require('../dist/vue-ssr-client-manifest.json')

app.use(express.static(path.resolve(__dirname, '../dist'), {index: false}))
// vue环境（webpack) 关联 Server
const render = ServerRender.createBundleRenderer(serverBundle, {
    template: fs.readFileSync('./index.ssr.html', 'utf8'),
    clientManifest,
})
// const render = ServerRender.createRenderer({
//   template: fs.readFileSync('./index.ssr.html', 'utf8'),
// });





app.get('*', async (req, res) => {
  try {
    // 2. 渲染器根据vm生成html字符串
  const url = req.url;
  const html = await render.renderToString({ title: 'SSR', desc: 'It is a page about SSR', url})
  res.send(html);
  } catch ({url, code}) {
    res.status(code).send(`状态码为:${code}，访问的路径是${url}`)
  }
});


app.listen(12307, () => console.log('server is running at 12306'));