const SSRClientPlugin = require('vue-server-renderer/client-plugin');
const SSRServerPlugin = require('vue-server-renderer/server-plugin');

const TARGET_NODE = process.env.WEBPACK_TARGET === 'node';
const target = TARGET_NODE ? 'server' : 'client'
module.exports = {
  configureWebpack: () => ({
    entry: `./src/entry/${target}.entry.js`,
    target: TARGET_NODE ? 'node' : undefined,
    output: {
      libraryTarget: TARGET_NODE ? 'commonjs2' : undefined,
    },
    optimization: {
      splitChunks: TARGET_NODE ? false: undefined
    },
    plugins: [TARGET_NODE ? new SSRServerPlugin() : new SSRClientPlugin()]
  })
}