<template>
  <div id="app">
    <h1>我是Vue根组件</h1>
    <router-link to="/">home</router-link>
    <router-link to="/about">about</router-link>
    <router-view></router-view>
    <!-- <Home/>
    <About/> -->
  </div>

</template>

<script>
// import Home from './components/home'
// import About from './components/about'
export default {
  // components: {
  //   Home,
  //   About
  // }
}
</script>

<style>

</style>