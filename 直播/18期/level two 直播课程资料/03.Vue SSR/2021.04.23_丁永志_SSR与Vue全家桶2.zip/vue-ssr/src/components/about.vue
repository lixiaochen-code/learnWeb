<template>
  <div>
    <h2>我是about页面</h2>
    <input type="text" v-model="val">
    <div>input中的内容：{{val}}</div>
  </div>
</template>

<script>
export default {
  data() {
    return {
      val: ''
    }
  }
}
</script>

<style>

</style>