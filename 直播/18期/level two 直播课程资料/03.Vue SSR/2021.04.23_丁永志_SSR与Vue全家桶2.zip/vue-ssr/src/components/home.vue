<template>
  <div>
    <h2>我是home页面</h2>
    <button @click="hitme">打我</button>
  </div>
</template>

<script>
export default {
  methods: {
    hitme() {
      alert('我被打了')
    }
  }
}
</script>

<style>

</style>