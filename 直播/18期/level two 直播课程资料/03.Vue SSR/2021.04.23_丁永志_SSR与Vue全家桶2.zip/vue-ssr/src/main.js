import Vue from 'vue';
import App from './app';
import router from './router';

// new Vue({
//   el: '#app',
//   render: h => h(App),
//   router,
// });

// el $mount

export default () => {
  const app = new Vue({
    render: h => h(App),
    router,
  });
  return { app, router }
}
