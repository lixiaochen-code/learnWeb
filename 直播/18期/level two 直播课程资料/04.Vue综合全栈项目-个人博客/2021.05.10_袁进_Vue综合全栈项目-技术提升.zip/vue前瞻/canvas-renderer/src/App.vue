<template>
  <rectangle
    :width="300"
    :height="100"
    background="red"
    color="#fff"
    :fontSize="20"
    :left="100"
    :top="100"
  >
    Hello World
  </rectangle>
  <circle
    :x="600"
    :y="200"
    :r="100"
    background="red"
    color="#fff"
    :fontSize="20"
  >
    一个圆
  </circle>
  <rectangle
    :width="300"
    :height="100"
    background="red"
    color="#fff"
    :fontSize="20"
    :left="100"
    :top="250"
  >
    你好
  </rectangle>
</template>

<script>
export default {};
</script>

<style>
body {
  margin: 0;
}
</style>
