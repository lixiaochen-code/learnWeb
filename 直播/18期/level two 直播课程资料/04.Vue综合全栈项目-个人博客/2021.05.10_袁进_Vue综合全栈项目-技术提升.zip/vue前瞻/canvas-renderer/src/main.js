import createApp from "./renderer";
import App from "./App.vue";
createApp(App).mount();
