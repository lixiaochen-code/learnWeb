export let canvas;
export let ctx;
canvas = document.createElement("canvas");
setCanvasSize();
document.body.appendChild(canvas);
ctx = canvas.getContext("2d");
canvas.style.display = "block";
function setCanvasSize() {
  canvas.width = document.documentElement.clientWidth;
  canvas.height = document.documentElement.clientHeight;
}
