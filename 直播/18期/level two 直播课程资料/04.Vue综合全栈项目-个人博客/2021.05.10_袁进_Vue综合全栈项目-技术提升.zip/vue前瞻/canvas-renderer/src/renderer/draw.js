import { ctx, canvas } from "./canvas";
const rectangleDefaultValues = {
  width: 100,
  height: 100,
  background: "lightblue",
  left: 0,
  top: 0,
};

const textDefaultValues = {
  fontSize: 16,
  color: "#000",
};
const circleDefaultValues = {
  background: "lightblue",
  x: 50,
  y: 50,
  r: 50,
};

const drawer = {
  drawRectangle(drawContent) {
    let drawObj = {
      ...rectangleDefaultValues,
      ...drawContent,
    };
    ctx.fillStyle = drawObj.background;
    ctx.fillRect(drawObj.left, drawObj.top, drawObj.width, drawObj.height);
    // 画文字
    const drawTextObj = {
      ...textDefaultValues,
      ...drawContent,
    };
    drawTextObj.centerX = drawObj.left + drawObj.width / 2;
    drawTextObj.centerY = drawObj.top + drawObj.height / 2;
    this.drawText(drawTextObj);
  },
  drawCircle(drawContent) {
    let drawObj = {
      ...circleDefaultValues,
      ...drawContent,
    };
    ctx.beginPath();
    ctx.fillStyle = drawObj.background;
    ctx.arc(drawObj.x, drawObj.y, drawObj.r, 0, 2 * Math.PI);
    ctx.fill();
    ctx.closePath();
    // 画文字
    const drawTextObj = {
      ...textDefaultValues,
      ...drawContent,
    };
    drawTextObj.centerX = drawObj.x;
    drawTextObj.centerY = drawObj.y;
    this.drawText(drawTextObj);
  },
  drawText(drawObj) {
    ctx.fillStyle = drawObj.color;
    ctx.textAlign = "center";
    ctx.font = `bold ${drawObj.fontSize}px sans-serif`;
    ctx.fillText(
      drawObj.value,
      drawObj.centerX,
      drawObj.centerY + drawObj.fontSize / 2
    );
  },
};

export default function (drawContent, parent) {
  if (drawContent.type === "shape") {
    // 画形状，目前支持的形状有：矩形、圆形
    const methodName =
      drawContent.tag[0].toUpperCase() + drawContent.tag.substr(1);

    drawer[`draw${methodName}`](drawContent, parent);
  }
}
