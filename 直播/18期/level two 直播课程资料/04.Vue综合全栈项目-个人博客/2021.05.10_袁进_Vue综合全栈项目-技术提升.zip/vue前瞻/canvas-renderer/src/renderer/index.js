import renderer from "./renderer";
import { canvas } from "./canvas";

export default function (App) {
  const app = renderer.createApp(App);
  const mount = app.mount;
  // 重写mount方法，执行初始操作
  app.mount = function () {
    mount(canvas);
  };
  return app;
}
