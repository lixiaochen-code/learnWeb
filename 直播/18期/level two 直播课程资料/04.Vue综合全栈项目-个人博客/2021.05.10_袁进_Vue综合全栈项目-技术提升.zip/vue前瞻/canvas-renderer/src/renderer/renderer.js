import { createRenderer } from "vue";
import draw from "./draw";
export default createRenderer({
  // 创建元素
  createElement(tag) {
    return { tag, type: "shape" };
  },
  // 插入元素
  insert(child, parent) {
    if (child.type === "shape" && child.tag === "text") {
      parent.value = child.value;
    } else {
      draw(child, parent);
    }
  },
  createText(text) {
    return {
      tag: "text",
      type: "shape",
      value: text,
    };
  },
  patchProp(el, key, prevValue, nextValue) {
    el[key] = nextValue;
  },
  setElementText(node, text) {
    node.value = text;
  },
});
